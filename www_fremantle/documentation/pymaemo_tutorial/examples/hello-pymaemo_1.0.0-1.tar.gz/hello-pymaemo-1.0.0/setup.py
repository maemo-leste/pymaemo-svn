from distutils.core import setup

setup(name='hello-pymaemo',
       version='1.0.0',
       scripts=['hello-pymaemo'],
       data_files = [
                    ('share/pixmaps',             ['hello_icon_26x26.png']),
                    ('share/applications/hildon', ['hello-pymaemo.desktop']),
                    ]
      )