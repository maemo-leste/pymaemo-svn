"""Suite Required Suite: Terms that every application should support
Level 1, version 1

Generated from /Developer/Applications/Apple Help Indexing Tool.app
AETE/AEUT resource version 1/1, language 0, script 0
"""

import aetools
import MacOS

_code = 'reqd'

from StdSuites.Required_Suite import *
class Required_Suite_Events(Required_Suite_Events):

    pass


#
# Indices of types declared in this module
#
_classdeclarations = {
}

_propdeclarations = {
}

_compdeclarations = {
}

_enumdeclarations = {
}
