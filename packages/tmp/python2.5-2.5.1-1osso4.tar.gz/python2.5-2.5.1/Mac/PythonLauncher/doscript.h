/*
 *  doscript.h
 *  PythonLauncher
 *
 *  Created by Jack Jansen on Wed Jul 31 2002.
 *  Copyright (c) 2002 __MyCompanyName__. All rights reserved.
 *
 */

#include <Carbon/Carbon.h>

extern int doscript(const char *command);